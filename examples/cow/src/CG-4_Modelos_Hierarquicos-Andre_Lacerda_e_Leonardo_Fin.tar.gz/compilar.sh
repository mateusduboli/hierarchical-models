gcc Main.c -o modelo.exe -lglut -lGL -lGLU -lm
